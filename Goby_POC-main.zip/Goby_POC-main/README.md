# Goby_POC
# POC 数量1319 
## 更新时间 2023/7/29 00:31:11
### 在公网收集的gobypoc+部分自己加的poc


* 360 TianQing ccid SQL injectable
* 360 TianQing database information disclosure
* 3ware default password vulnerability
* 74CMS Resume.php Boolean SQLI
* 74CMS SQLi with Plus ajax common
* 74CMS SQLi with Plus weixin
* AceNet AceReporter Report component Arbitrary file download
* ACME mini_httpd Arbitrary File Read (CVE-2018-18778)
* ACTI Camera images File read
* ActiveMQ Arbitrary File Write Vulnerability (CVE-2016-3088)
* ActiveMQ Deserialization Vulnerability (CVE-2015-5254)
* Active UC index.action RCE
* Adminer SSRF (CVE-2021-21311)
* Adobe ColdFusion 11 LDAP Java Object Deserialization
* Adobe ColdFusion Java Deserialization RCE (CVE-2017-3066)
* Adobe ColdFusion upload.cfm file upload (CVE-2018-15961)
* Adobe ColdFusion 8.0/8.0.1/9.0/9.0.1 LFI CVE-2010-2861
* ADSelfService Plus RCE CVE-2021-40539
* ADSelfService Plus RCE CVE-2021-40539
* adslr router default password
* Adslr Enterprise online behavior management system Information leak
* Adslr Enterprise online behavior management system Information leakage
* AIC Intelligent Campus System Password Leak
* Alibaba Nacos 控制台默认弱口令
* Alibaba Nacos 未授权访问漏洞
* Alibaba Canal Default Password
* Alibaba Nacos Add user not authorized
* Alibaba Nacos Default Password
* Amcrest/Dahua Unauthenticated-Audio-Streaming (CVE-2019-3948)
* Amcrest IP Camera Information Disclosure (CVE-2017-8229)
* Ametys CMS infoleak CVE-2022-26159
* AMTT eFlow HiBOS server Ping Command Injection
* anhuiyangguangmulubianli
* AntD Admin Sensitive Information Disclosure Vulnerability (CVE-2021-46371)
* Apache ActiveMQ Console控制台弱口令
* Apache Cocoon Xml 注入 CVE-2020-11991
* Apache Kylin Console 控制台弱口令
* Apache Kylin 未授权配置泄露 CVE-2020-13937
* Apache Solr任意文件读取漏洞
* Apache Solr任意文件读取漏洞
* Apache <= 2.4.48 Mod_Proxy SSRF (CVE-2021-40438)
* Apache 2.4.49 2.4.50 Path Traversal (CVE-2021-42013)
* Apache 2.4.49 Path Traversal (CVE-2021-41773)
* Apache Airflow Example Dag RCE (CVE-2020-11978)
* Apache APISIX Admin API Default Access Token (CVE-2020-13945)
* Apache APISIX Dashboard Unauthorized Access Vulnerability
* Apache Axis2 1.4.1 Remote Directory Traversal Vulnerability (CVE-2010-0219)
* Apache Druid Arbitrary File Read (CVE-2021-36749)
* Apache Druid RCE (CVE-2021-25646)
* Apache Flink File Upload (CVE-2020-17518)
* Apache Flink Path Traversal (CVE-2020-17519)
* Apache James Log4j2 command execution vulnerability(CVE-2021-44228)
* Apache Kylin Post-Auth Command Injection (CVE-2020-13925)
* Apache NiFi Api RCE
* Apache OFBiz Bypass RCE (CVE-2021-30128)
* Apache OFBiz Deserialization RCE (CVE-2020-9496)
* Apache OFBiz rmi RCE (CVE-2021-26295)
* Apache OFBiz XXE File Read (CVE-2018-8033)
* Apache Shiro CVE-2016-4437 Information Disclosure Vulnerability
* Apache SkyWalking RCE with SQLi
* Apache Solr Arbitrary file read
* Apache Solr collections file action parameter Log4j2 command execution vulnerability
* Apache Solr Velocity Template RCE (CVE-2019-17558)
* Apache Struts 'includeParams' CVE-2013-1966 Security Bypass Vulnerability
* Apache Struts CVE-2017-12611 Remote Code Execution Vulnerability
* Apache Struts CVE-2017-5638 Remote Code Execution Vulnerability
* Apache Struts CVE-2017-9805 Remote Code Execution Vulnerability
* Apache Tapestry Unserialize RCE (CVE-2021-27850)
* Apache Tomcat CVE-2017-12615 Remote Code Execution Vulnerability
* Apache Unomi RCE (CVE-2020-13942)
* Apache 2.4.49 Path Traversal (CVE-2021-41773)
* Apache 2.4.49 RCE (CVE-2021-41773) and 2.4.50 (CVE-2021-42013)
* Apache ActiveMQ_Console Weak Password
* Apache ActiveMQ default admin account
* Apache Airflow Unauthorized
* Apache APISIX Admin API Default Token CVE-2020-13945
* Apache APISIX Dashboard API Unauthorized Access CVE-2021-45232
* Apache APISIX Dashboard CVE-2021-45232
* Apache APISIX Dashboard RCE CVE-2021-45232
* Apache Cocoon XML Injection CVE-2020-11991
* Apache CouchDB Remote Privilege Escalation CVE-2017-12635
* Apache CouchDB Unauth
* Apache Druid Abritrary File Read CVE-2021-36749
* Apache Druid Abritrary File Read CVE-2021-36749
* Apache Druid Arbitrary File Read (CVE-2021-36749)
* Apache Druid Log4shell CVE-2021-44228
* Apache Druid Log4shell CVE-2021-44228
* Apache Dubbo Admin Default Password
* Apache Flink CVE-2020-17519
* Apache HTTP Server 2.4.48 mod_proxy SSRF CVE-2021-40438
* Apache HTTP Server 2.4.49 2.4.50 Path Traversal CVE-2021-42013
* Apache HTTP Server 2.4.49 Path Traversal CVE-2021-41773
* Apache HTTP Server 2.4.49 RCE CVE-2021-41773
* Apache HTTP Server Arbitrary File Read(CVE-2021-41773)
* Apache HTTP Server SSRF CVE-2021-40438
* Apache HTTP Server SSRF CVE-2021-40438
* Apache JSPWiki Log4shell CVE-2021-44228 (1)
* Apache JSPWiki Log4shell CVE-2021-44228 (2)
* Apache JSPWiki Log4shell CVE-2021-44228 (1)
* Apache JSPWiki Log4shell CVE-2021-44228 (2)
* Apache Kylin Console default password
* Apache Kylin API Unauthorized Access CVE-2020-13937
* Apache OFBiz Log4shell CVE-2021-44228
* Apache OFBiz Log4shell CVE-2021-44228
* Apache ShenYu Admin Unauth Access CVE-2022-23944
* Apache SkyWalking Log4shell CVE-2021-44228
* Apache SkyWalking Log4shell CVE-2021-44228
* Apache Solr Arbitrary File Read
* Apache Solr Log4j2远程代码执行漏洞（CVE-2021-44228）
* Apache_Solr_RemoteStreaming文件读取与SSRF漏洞
* Apache Struts2 S2-053 RCE CVE-2017-12611
* Apache Struts2 S2-059 RCE CVE-2019-0230
* Apache Struts2 S2-062 RCE CVE-2021-31805
* apereo CAS log4shell RCE vulnerability (CVE-2021-44228)
* AppWeb Authentication Bypass vulnerability (CVE-2018-8715)
* Arcadyan Routers Authentication Bypassing (CVE-2021–20090)
* Aruba Instant password vulnerability
* ASPCMS commentList.asp SQLi
* Aspcms Backend Leak
* AspCMS commentList.asp SQL注入漏洞
* Atlassian Jira 信息泄露漏洞 CVE-2020-14181
* Atlassian Jira 信息泄露漏洞 CVE-2020-14181
* Atlassian Confluence RCE (CVE-2021-26084)
* Atlassian Confluence Webwork OGNL Inject (CVE-2022-26134)
* Atlassian Confluence 远程代码执行漏洞（CVE-2022-26134）
* Atlassian Jira  Authentication bypass in Seraph (CVE-2022-0540)
* Atlassian Confluence OGNL Injection CVE-2021-26084
* Atlassian Confluence OGNL Injection RCE CVE-2022-26134
* Atlassian Jira Path Traversal CVE-2021-26086
* Atlassian Jira Seraph Authentication bypass CVE-2022-0540
* Atlassian Jira user information disclosure (CVE-2020-14181)
* Atlassian Jira user information disclosure CVE-2020-14181
* AvaVideos SingleUpload Servlet File Upload
* Avaya Aura Default Credentials
* AVCON-6 download.action File Read (CNVD-2020-30193)
* AVCON6 org_execl_download.action file down
* Axis2 Default Credentials Remote Code Execution (CVE-2010-0219)
* Barco/AWIND OEM Presentation Platform Unauthenticated Remote Command Injection (CVE-2019-3929)
* BIG-IP iControl REST vulnerability (CVE-2022-1388)
* BigAnt Server v5.6.06 Path Traversal CVE-2022-23347
* BIND server DoS (CVE-2020-8617)
* Bitbucket Data Center Unauthenticated Remote Code Execution Vulnerability (CVE-2022-26133)
* Bithighway L7 RCE (CNVD-2021-41531)
* BSPHP index.php unauthorized access information
* Byzoro smart importhtml.php RCE (CNVD-2021-40201)
* C-Data Tec CPE-WiFi default password
* C-Lodop Arbitrary File Read (CNVD-2019-43826)
* Cacti Weathermap File Write
* CAIMORE Wireless Router RCE
* Casdoor 1.13.0 SQL Injection（CVE-2022-24124）
* Caucho Resin 4.0.52 4.0.56 Directory Traversal
* fumengyun  AjaxMethod.ashx SQL injection
* Chamilo model.ajax.php SQL (CVE-2021-34187)
* Chanjet unauthorized access and admin password reset
* chanjet CRM get_usedspace.php sql injection
* Chanjet CRM get_usedspace.php sql injection CNVD-2021-12845
* Chemex Auth File Upload CNVD-2021-15573
* China Mobile IPTV getshell
* ChinaTelecom sjkd camera default password
* 中国移动 禹路由 登录绕过
* China Mobile Yu Routing ExportSettings.sh Info Leak CNVD-2020-67110
* China Mobile Yu Routing Login Bypass
* 中国移动 禹路由 敏感信息泄露漏洞
* ChronoForums 2.0.11 Directory Traversal
* Ciphertrust default password vulnerability
* CirCarLife SCADA 4.3 Credential Disclosure
* Cisco ACE 4710 Device Manager Default Credentials
* Cisco ASA and FTD File Delete (CVE-2020-3187)
* Cisco ASA and FTD File Read (CVE-2020-3452)
* Cisco CloudCenter Suite log4j2 Remote command execution vulnerability (CVE-2021-44228)
* Cisco HyperFlex HX Data Platform Command Injection (CVE-2021-1498)
* Cisco HyperFlex HX Data Platform File Upload (CVE-2021-1499)
* Cisco HyperFlex HX Installer Python Code Injection (CVE-2021-1497)
* cisco prime infrastructure unauthorized RCE(CVE-2019-1821)
* Cisco RV110W RV130W RV215W router Information leakage
* Cisco RV320 and RV325 Routers CVE-2019-1652 Remote Command Injection Vulnerability
* Cisco RV340 Auth RCE (CVE-2021-1414)
* Cisco RV340 RCE (CVE-2021-1473)
* Cisco Small Business RV Series Routers Multiple Command Execution Vulnerabilities (CVE-2022-20705  CVE-2022-20707)
* Citrix ADC RCE (CVE-2019-19781)
* Citrix ShareFile Storage RCE (CVE-2021-22941)
* Citrix XenMobile Arbitrary file read (CVE-2020-8209)
* Citrix unauthenticated LFI CVE-2020-8193
* Citrix Unauthorized CVE-2020-8193
* ClickHouse SQLI
* ClusterEngine V4.0 Arbitrary command execution vulnerability
* ClusterEngine V4.0 sysShell RCE Arbitrary command execution vulnerability
* ClusterEngineV4.0 RCE (CVE-2020-21224)
* ClusterEngine V4.0 Shell cluster RCE
* CmsEasy crossall_act.php SQL injection vulnerability
* cnzxsoft information security management system default account
* Coldfusion LFI CVE-2010-2861
* COMMAX Ruvie CCTV Bridge DVR Unauthorized access
* Commvault CVSearchService Authentication Bypass (CVE-2021-34993)
* Compact backdoors (CVE-2021-40859)
* Confluence RCE (CVE-2019-3396)
* Confluence Viewdecorator.action File Read (CVE-2015-8399)
* Confluence RCE(CVE-2021-26084)
* Consul Service API RCE
* Consul Rexec RCE
* Control-M log4j2 Remote command execution vulnerability (CVE-2021-44228)
* Coremail Information Leakage (CNVD-2019-16798)
* Coremail configuration information disclosure
* Coremail Config Disclosure
* CoreOS ETCD API Unauthorized Access
* CouchCMS Infoleak CVE-2018-7662
* Couchdb Add User Not Authorized CVE-2017-12635
* Couchdb Unauth
* Couch CMS Infoleak CVE-2018-7662
* CraftCMS SEOmatic component SSTI (CVE-2020-9757)
* CraftCMS Seomatic RCE CVE-2020-9597
* CraftCMS SEOmatic Server-Side Template Injection CVE-2020-9597
* Crawlab Arbitrary File Read
* Crestron Hd-Md4X2 Credential Disclosure (CVE-2022-23178)
* CRMEB DaTong sid sqli
* Crocus default password vulnerability
* CVE-2019-0708 BlueKeep Microsoft Remote Desktop RCE
* Portainer为创建用户导致未授权访问(CVE-2018-19367)
* F5 BIG-IP iControl REST 远程代码执行(CVE-2022-1388)
* CVE-2022-22947
* D-Link AC集中管理系统默认弱口令
* D-Link AC集中管理系统默认弱口令
* D-Link DCS系列监控 账号密码信息泄露漏洞 CNVD-2020-25078
* D-Link DCS系列监控 账号密码信息泄露漏洞 CNVD-2020-25078
* D-Link DCS系列监控 账号密码信息泄露漏洞 CNVD-2020-25078
* D-Link DCS系列监控 账号密码信息泄露漏洞 CNVD-2020-25078
* D-Link 850L and 645 Information Disclosure
* D-Link DAP-2020 File Read (CVE-2021-27250)
* D-Link DIR-600M Wireless N 150 Login Page Bypass
* D-Link Dir-645 getcfg.php Account password disclosure (CVE-2019-17506)
* D-Link DNS-320 login_mgr.cgi RCE (CVE-2019-16057)
* D-Link DSL-28881A Unauthorized_access (CVE-2020-24579)
* D-Link DSL-2888A RCE (CVE-2020-24581)
* D-Link Dump Credentials (CVE-2020-9376)
* D-Link ShareCenter DNS-320 system_mgr.cgi RCE
* D-Link AC management system Default Password
* D-Link DCS-2530L Administrator password disclosure CVE-2020-25078
* D-Link DIR-850L Info Leak
* D-LINK DIR-868L x DIR-817LW Info Leak CVE-2019-17506
* D-Link Info Leak CVE-2019-17506
* D-Link ShareCenter DNS-320 RCE
* Dahua DSS RCE (CNVD-2017-08805)
* Dahua DSS System Arbitrary file download CNVD-2020-61986
* DaHua Login Bypass (CVE-2021-33044)
* DaHua Login Bypass (CVE-2021-33045)
* Dahua Wisdom park System user_getUserInfoByUserName.action Information Disclosure
* 大华DSS系统 任意文件下载漏洞
* Datang AC Default Password
* DedeCMS 5.8.1 RCE
* DedeCMS mysql_error_trace.inc infoleak
* DedeCMS recommend.php SQLi (CVE-2017-17731)
* DedeCMS Carbuyaction FileInclude
* DedeCMS InfoLeak CVE-2018-6910
* DedeCMS InfoLeak CVE-2018-6910
* Dell DARC Default Credentials
* Discuz!ML v3.x GETSHELL
* Discuz!ML 3.x RCE CNVD-2019-22239
* Discuz 3.3 RCE getshell
* Discuz 7.x/6.x global variable defense bypass rce
* Discuz!ML 3.x RCE CNVD-2019-22239
* Discuz RCE WOOYUN-2010-080723
* Discuz v72 SQLI
* Discuz Wechat Plugins Unauth
* Dixell XWEB500 Arbitrary File Write
* DLink DNS ShareCenter RCE (CNVD-2020-53563)
* DLINK rtpd.cgi Command Injection (CVE-2013-1599)
* Dlink 850L Info Leak
* Dlink Info Leak CVE-2019-17506
* Dlink RCE CVE-2019-16920
* DNNarticle file manage system GetCSS.ashxy Dbinfo leakage
* DocCMS keyword SQL injection Vulnerability
* Docker Registry API Unauth
* dotCMS content Arbitrary File Upload (CVE-2022-26352)
* DotCMS Arbitrary File Upload CVE-2022-26352
* DrayTek pre-auth remote root RCE (CVE-2020-8515)
* Drupal avatar_uploader Local File Inclusion (CVE-2018-9205)
* Drupal Core Arbitrary PHP Code Execution Vulnerability(CVE-2019-6340)
* Drupal Core Multiple Remote Code Execution Vulnerabilities(CVE-2018-7600)
* Drupal Core Remote Code Execution Vulnerability(CVE-2018-7602)
* Drupal Core SQL Injection Vulnerability(CVE-2014-3704)
* DSS File Read
* DSS Unauth File Upload Getshell
* DS_Store found
* Dubbo RCE (CVE-2020-1948)
* Dubbo Admin Default Password
* DuomiCms SQLi (CNVD-2018-05568)
* Dwsurvey 3.2 Arbitrary File Read
* D-Link AC Centralized management system  Default weak password
* D-Link DC Disclosure of account password information (CVE-2020-25078)
* D-Link-DIR-868L getcfg.php Account password leakage
* D-Link ShareCenter DNS-320 RCE
* ECOA Building System multiple vulnerabilities
* ECShop 2.x_3.x sqli
* ecshop 4.1.0 delete_cart_goods.php SQLi
* ECShop delete_cart_goods.php SQLi
* eGroupWare spellchecker.php RCE
* Elasticsearch Remote Code Execution CVE-2014-3120
* Elasticsearch Remote Code Execution CVE-2015-1427
* Emby MediaServer 3 Directory Traversal File Disclosure
* Emby MediaServer RemoteSearch SSRF (CVE-2020-26948)
* Emlog 5.3.1 Path Disclosure (CVE-2021-3293)
* EnGenius EnShare IoT Gigabit Cloud Service RCE
* ESAFENET CDG arbitrary file download (CVE-2019-9632)
* ESAFENET DLP dataimport RCE
* Esafenet Document Security Management System SystemService RCE
* eSSL DataApp unauth database download
* EVERFOCUS  EPARA Directory Traversal
* Evolucare Ecs imaging RCE (CVE-2021-3029)
* Eyou Mail system moni_detail.do RCE
* EyouCMS less than 1.4.2 SSTI
* EyouCMS Session brute force Bypass login
* Eyou Mail system RCE
* Eyou Mail System RCE CNVD-2021-26422
* F5-BIG-IP-login-bypass-CVE-2022-1388
* F5 BIG-IP TMUI RCE (CVE-2020-5902)
* F5 BIGIP iControl unauth RCE (CVE-2021-22986)
* F5 BIG-IP iControl REST API auth bypass CVE-2022-1388
* F5 BIG-IP iControl REST Unauthenticated RCE CVE-2021-22986
* F5 BIG-IP代码执行漏洞（CVE-2021-22986）exp
* Fahuo100 SQL Injection CNVD-2021-30193
* Fastjson 1.2.24 RCE (CNVD-2017-02833)
* Fastjson 1.2.47 RCE (CNVD-2019-22238)
* Fastmeeting Arbitrary File Read
* FAUST iServer File Read (CVE-2021-34805)
* feishimei struts2 remote code
* FileRun 2021.03.26 Auth RCE (CVE-2021-35504)
* FineCMS Remote Command Execution (CNVD-2019-36681)
* FineReport Arbitrary File Read
* FineReport ReportServer File Overwrite getshell
* FineReport（帆软）报表系统目录遍历漏洞
* FineReport v8.0 Arbitrary file read 
* FineReport v8.0 Fileread CNVD-2018-04757
* FineReport v8.0/v9.0 Directory Traversal
* FineReport v9 Arbitrary File Overwrite
* Finetree-5MP-摄像机 默认口令 未授权任意用户添加
* Finetree 5MP Network Camera Default Login unauthorized user add
* 防火墙设备账号密码泄露漏洞
* FLIR-AX8 Arbitrary File Download Vulnerability
* ForgeRock AM RCE (CVE-2021-35464)
* ForgeRock AM RCE CVE-2021-35464
* FortiLogger Unauth Arbitrary File Upload(CVE-2021-3378)
* Fortinet FortiOS CVE-2018-13379 Directory Traversal Vulnerability 
* fumengyun  AjaxMethod.ashx SQL injection
* Gateone Arbitrary File Read (CVE-2020-35736)
* Geneko Routers Path Traversal
* Gerapy 0.9.6 Arbitrary File Read
* Git repository found
* GitLab Graphql邮箱信息泄露漏洞 CVE-2020-26413
* GitLab Graphql邮箱信息泄露漏洞 CVE-2020-26413
* GitLab CE/EE Unauthenticated RCE (CVE-2021-22205)
* Gitlab CI Lint API SSRF (CVE-2021-22214)
* GitLab information leak (CVE-2020-26413)
* GitLab Graphql Email information disclosure (CVE-2020-26413)
* GitLab Graphql Email information disclosure CVE-2020-26413
* GitLab RCE CVE-2021-22205
* Gitlab RCE CVE-2021-22205
* GitLab SSRF CVE-2021-22214
* GlassFish Arbitrary File Read (CVE-2017-1000028)
* GlassFish Server Open Source Edition 3.01 Local File Inclusion
* Glodon T platform default credentials vulnerability
* GLPI 9.3.3 sqli (CVE-2019-10232)
* GLPI Barcode Arbitrary File Read(CVE-2021-43778)
* GoAhead Web Server LD_PRELOAD Arbitrary Module Load (CVE-2017-17562)
* GoCD Arbitrary File Read
* GoCD Arbitrary file reading CVE-2021-43287
* GoCD Unauthorized Path Traversal CVE-2021-43287
* Grafana Arbitrary File Read vulnerability
* Grafana Zabbix Information Leakage (CVE-2022-26148)
* Grafana Angularjs Rendering XSS CVE-2021-41174
* Grafana Arbitrary file read
* Grafana Plugins Arbitrary File Read CVE-2021-43798
* Grafana v8.x Arbitrary File Read CVE-2021-43798
* GravCMS Unauthenticated Code Execution Vulnerability
* Gurock Testrail 7.2 Information leakage (CVE-2021-40875)
* H3C HG659 lib File Read
* H3C IMC dynamiccontent.properties.xhtm RCE
* H3C IMC PrimeFaces 5.x Arbitrary command execution vulnerability
* H3C Next generation firewall File read
* H3C SecPath Operation Login bypass
* H3C SECPATH Operations and Maintenance Audit System RCE
* H3C SECPATH Operations and Maintenance Audit System
* H3C IMC RCE
* H5S GetUserInfo Information leakage (CNVD-2020-67113)
* H5S CONSOLE Video Platform GetSrc Info Leak CNVD-2021-25919
* H5S video platform GetSrc information leakage
* H5S video platform GetUserInfo Account password leakage
* H5S Video Platform GetUserInfo Info Leak CNVD-2021-35567
* Hadoop YARN ResourceManager远程命令执行漏洞
* Hadoop Yarn RPC service unauthorized access rce vulnerability
* Hanvon kaoqin Login.action S2-005 RCE
* HanWang Time Attendance SQL injection
* HaoShiTong Meeting system toDownload.do file read
* Harbor Default Credentials
* Harbor Remote Privilege Escalation Vulnerability (CVE-2019-16097)
* HD-Network Real-time Monitoring System 2.0 Local File Inclusion (CVE-2021-45043)
* HEJIA PEMS SystemLog.cgi Arbitrary file_download
* HIKVISION 视频编码设备接入网关 任意文件下载
* HIKVISION Video coding equipment Download any file
* Hikvision Web Server RCE (CVE-2021-36260)
* HIKVISION流媒体管理服务器
* Hikvision RCE CVE-2021-36260
* Hikvision Unauthenticated RCE CVE-2021-36260
* HIKVISION Video coding equipment Download any file
* Hikvision Video Encoding Device Access Gateway Any File Download
* Hipcam User Credential Disclosure
* Holographic AI network operation and maintenance platform RCE
* Hongdian H8922 Arbitrary File Read (CVE-2021-28149)
* HongFan ioffice OA RCE
* HotelDruid Hotel Management Software v3.0.3 XSS CVE-2022-26564
* HP iLO4 Login Authentication Bypass (CVE-2017-12542)
* Hsmedia Hgateway default account
* Hsmedia Hgateway login SQli
* D-Link AC Centralized management system  Default weak password
* huatiandongliOA 8000workFlowService SQLinjection
* Huawei HG532 CVE-2017-17215 Remote Code Execution Vulnerability
* Huawei home gateway HG659 fileread
* Huijietong cloud video fileDownload File read
* Huijietong cloud video list Information leakage
* Hyperic Default Credentials
* Hysine webtalk defaulte password vulnerability
* IBM Informix Open Admin Tool RCE (CVE-2017-1092)
* IBM Spectrum Protect Plus hostname rce
* IBM Spectrum Protect Plus npassword rce
* IBM Spectrum Protect Plus password rce
* IBM Spectrum Protect Plus username rce
* IBM WebSphere Application Server Deserialization RCE (CVE-2020-4450)
* IceWarp mail system Local File Inclusion
* IceWarp WebClient basic RCE
* iDVR system file traversal
* IFW8 Enterprise router v4.31 Password leakage 
* IFW8 Enterprise router v4.31 Password leakage 
* IFW8 Router ROM v4.31 Credential Discovery CVE-2019-16313
* Intellian Aptus Web RCE (CVE-2020-7980)
* iRDM4000 cookie bypass
* IRDM4000 Smart station Unauthorized access
* Ivanti Endpoint Manager code injection (CVE-2021-44529)
* iXCache has weak password vulnerability
* JBoss <= 6.x Unauthenticated Java Deserialization rce
* JCG Wireless Route Ping Host RCE
* JEECG 4.0 IconController Arbitrary File Upload
* JEESITE V1.2.7 File Read
* JEEWMS Arbitrary File Read Vulnerability
* Jellyfin Audio File read (CVE-2021-21402)
* Jellyfin 10.7.0 Unauthenticated Abritrary File Read CVE-2021-21402
* Jellyfin 10.7.2 SSRF CVE-2021-29490
* Jellyfin prior to 10.7.0 Unauthenticated Arbitrary File Read CVE-2021-21402
* Jellyfin SSRF CVE-2021-29490
* Jenkins Multiple Security Vulnerabilities
* Jenkins Script Security and Pipeline RCE(CVE-2019-1003000)
* Jenkins unauthenticated RCE (CVE-2017-1000353)
* JetBrains .idea project directory
* JetLinks Default password
* Jetty File Read (CVE-2021-28164)
* Jetty WEB-INF FileRead CVE-2021-28169
* Jetty WEB-INF FileRead CVE-2021-34429
* JingHang online marking Arbitrary File Upload
* JingHe OA download.asp File read
* JingHe OA C6 Default password
* 金和OA C6 download.jsp 任意文件读取漏洞
* JinHe OA C6 Default password
* JinHe OA C6 download.jsp Arbitrary fileread
* 金山 V8
* Jira SSRF in the makeRequest resource (CVE-2019-8451)
* 极通EWEBS任意文件读取
* Jitong EWEBS Fileread
* Jitong EWEBS phpinfo leak
* Joomla 3.7.0 SQLI (CVE-2017-8917)
* Joomla content management system com_macgallery plugin database file leaked
* JQuery 1.7.2版本站点前台任意文件下载漏洞
* JQuery 1.7.2 Filedownload
* Kedacom DVR Access gateway File Read
* KEDACOM MTS transcoding server Arbitrary file download CNVD-2020-48650
* KEDACOM MTS transcoding server Fileread CNVD-2020-48650
* KevinLAB BEMS 1.0 backdoor (CVE-2021-37292)
* Keycloak 12.0.1 SSRF (CVE-2020-10770)
* Kingdee EAS server_file Directory traversal
* kingsoft V8 terminal security system RCE
* Kingsoft V9 Terminal Security System Any File Upload
* Kingsoft V8 Arbitrary file read
* Kingsoft V8 Default weak password
* Kingsoft V8+ Terminal Security System Default Login CNVD-2021-32425
* Kingsoft V8+ Terminal Security System Fileread
* kkFileView Arbitrary File Read Vulnerability (CVE-2021-43734)
* kkFileView SSRF vulnerability
* Klog Server Unauth RCE(CVE-2020-35729)
* Kong API Gateway Unauthorized (CVE-2020-11710)
* Konga Default JWT KEY
* Kyan Network monitoring Password Leakage And run.php RCE
* Kyan Network monitoring time RCE
* Kyan
* Kyan 网络监控设备 账号密码泄露
* Kyan design account password disclosure
* Kyan network monitoring device account password leak
* Kyan network monitoring device run.php RCE
* Kyan 网络监控设备 run.php 远程命令执行漏洞
* laifuyun_sqli
* Landray OA arbitrary file read
* Landray OA custom.jsp RCE
* landray-OA-Arbitrary-file-read
* Landray OA custom.jsp Fileread
* LanhaiZuoyue system debug.php RCE
* LanhaiZuoyue system download.php File read
* Lanproxy 目录遍历漏洞 CVE-2021-3019
* lanproxy Directory Traversal (CVE-2021-3019)
* Lanproxy_Arbitrary_File_Read_CVE-2021-3019
* Lanproxy Directory Traversal CVE-2021-3019
* Lanxin log4j2 Remote command execution vulnerability (CVE-2021-44228)
* Laravel .env 配置文件泄露 CVE-2017-16894
* Laravel Framework Voyager Path traversal
* Laravel RCE (CVE-2021-3129)
* Laravel .env configuration file leaks (CVE-2017-16894)
* Laravel .env configuration file leaks CVE-2017-16894
* Leadsec SSL VPN file upload getshell
* Leadsec ACM infoleak CNVD-2016-08574
* Leadsec ACM information leakage CNVD-2016-08574
* LEMS Power Management System RCE
* LG SuperSign EZ CMS rce
* Liferay Portal Java Unmarshalling via JSONWS RCE (CVE-2020-7961)
* LINKSYS TomatoUSB shell.cgi RCE
* Logbase Bastionhost SQL Injection
* Longjing Technology BEMS API 1.21 Remote Arbitrary File Download
* LotWan static_arp.php RCE
* LOYTEC LINX Traversal File CVE-2018-14918
* Mailgard Firewall default account
* Mailgard Firewall ping function rce
* mallgard
* Mallgard Firewall Default Login CNVD-2020-73282
* ManageEngine ADManager Plus File upload vulnerability(CVE-2021-42002)
* ManageEngine OpManager infoleak (CVE-2020-11946)
* ManageEngine OpManager RCE (CVE-2020-28653)
* ManageEngine OpManger arbitrary file read (CVE-2020-12116)
* Many network devices have arbitrary file downloads
* Many network devices have password leaks
* MCMS 5.2.4 Arbitrary File Upload
* MCMS 5.2.4 categoryId sqli
* MessageSolution  邮件归档系统EEA 信息泄露漏洞 CNVD-2021-10543
* MessageSolution  邮件归档系统EEA 信息泄露漏洞 CNVD-2021-10543
* MessageSolution EEA info leakage (CNVD-2021-10543)
* MessageSolution EEA information disclosure (CNVD-2021-10543)
* MessageSolution EEA information disclosure CNVD-2021-10543
* Metabase geojson Arbitrary file reading CVE-2021-41277
* Metabase Geojson Arbitrary File Read CVE-2021-41277
* Metabase Geojson Arbitrary File Read CVE-2021-41277
* MeterSphere Remote Code Execution
* Metinfo 5.3.17 X-Rewrite-URL SQLi
* Metinfo met_download_list SQL time delay injection
* MFC-L2710DW default password vulnerability
* Microsoft Exchange SSRF漏洞 CVE-2021-26885
* Microsoft Exchange SSRF漏洞 CVE-2021-26885
* Microsoft Exchange Server File Write (CVE-2021-27065)
* Microsoft Exchange Server Remote Code Execution Vulnerability (CVE-2021-34473)
* Microsoft Exchange Server SSRF (CVE-2021-26855)
* Microsoft Exchange XSS (CVE-2021-41349)
* Microsoft SharePoint Server CVE-2019-0604 Remote Code Execution Vulnerability
* Microsoft Exchange Server SSRF CVE-2021-26885
* Micro module monitoring system User_list.php information leakage
* Mida eFramework ajaxreq.php RCE(CVE-2020-15920)
* MinIO Console Information Disclosure (CVE-2021-41266)
* MinIO default account
* MinIO Browser API SSRF CVE-2021-21287
* MkDocs Arbitrary File Read (CVE-2021-40978)
* MobileIron Log4shell CVE-2021-44228
* MobileIron Log4shell CVE-2021-44228
* Mobinat Wireless Router system_log.cgi RCE
* mongo-express rce(CVE-2019-10758)
* MovableType RCE (CVE-2021-20837)
* MPSec ISG1000 Gateway Filedownload CNVD-2021-43984
* 迈普 ISG1000安全网关 任意文件下载漏洞
* Multiple D-Link Routers RCE (CVE-2019-16920)
* Multiple firewall devices information leakage vulnerabilities
* Multiple models routers Background RCE CVE-2018-16752 
* Multiple Netgear Routers Remote Command Injection Vulnerability (CVE-2016-6277)
* Multiple RedHat JBoss Products CVE-2015-7501 Remote Code Execution Vulnerability
* Multiple Security Gateway Frontend RCE
* Multiple Security Gateway RCE aaa_portal_auth_config_reset
* MySQL Login Bypass Vulnerability (CVE-2012-2122)
* NatShell Billing System Debug RCE
* NatShell Billing System download.php File read
* NETENTSEC(WangKang) firewall NS-NGFW RCE
* Netentsec NGFW FireWall Anyterm-module RCE
* Netentsec NS ASG index.php RCE
* Netflix Conductor RCE (CVE-2020-9296)
* NETGEAR DGND3700v2 路由器 c4_IPAddr 远程命令执行漏洞
* NetShare VPN Default account password
* Netsweeper Webadmin unixlogin.php RCE (CVE-2020-13167)
* Netsweeper Webadmin unixlogin.php RCE
* Netsys online_check.php RCE
* Next.js Directory Traversal (CVE-2020-5284)
* Nexus Repository Manager 2 default account
* Nexus Repository Manager 3 RCE (CVE-2019-7238)
* NexusDB path traversal (cve-2020-24571)
* Node-red UI_base Arbitrary File Read Vulnerability CVE-2021-3223
* Node-RED ui_base Arbitrary File Read CVE-2021-3223
* Node.js systeminformation (CVE-2021-21315)
* Node.js Path Traversal CVE-2017-14849
* Node-RED ui_base Arbitrary File Read
* nostromo nhttpd Directory Traversal Remote Command Execution Vulnerability (CVE-2011-0751)
* nsoft EWEBS casmain.xgi File Read
* NuCom 11N Wireless Router v5.07.90 Remote Privilege Escalation
* NUUO Network Video handle_load_config.php Unauth Command Execution vulnerability(CVE-2019-9653)
* NVRmini RCE (CVE-2018-14933)
* NVS3000 integrated video surveillance platform is not accessible CNVD-2021-19742
* OpenCats 9.4.2 XXE (CVE-2019-13358)
* Openfire SSRF (CVE-2019-18394)
* OpenMRS log4j2 Remote command execution vulnerability (CVE-2021-44228)
* OpenSMTPD Remote Code Execution Vulnerability (CVE-2020-7247)
* OpenSNS Remote Code Execution
* OpenSNS Application ShareController.class.php  remote command execution vulnerability
* OpenSNS RCE
* OpenSSL远程代码执行漏洞 （CVE-2022-2274）
* Optilink Management system gene.php RCE
* Oracle Application Server File Read (CVE-2020-14864)
* Oracle E-Business Suite default account
* Oracle Java SE CVE-2011-3556 Remote Java Runtime Environment Vulnerability
* Oracle MySQL Server DoS (CVE-2017-3599)
* Oracle Weblogic Server Deserialization RCE(CVE-2018-2628)
* Oracle WebLogic Server Remote Security Vulnerability (CVE-2017-10271&CVE-2017-3506)
* Oracle WebLogic Unauthenticated RCE (CVE-2020-14882/CVE-2020-14750)
* Oracle WebLogic Unauthenticated Takeover (CVE-2020-14883)
* Oracle Weblogic LDAP RCE CVE-2021-2109
* Oracle Weblogic SearchPublicRegistries.jsp SSRF CVE-2014-4210
* Oracle WebLogic Server Path Traversal CVE-2022-21371
* Orange Livebox ADSL modems dis wifi pass CVE-2018-20377
* Oray Sunlogin RCE CNVD-2022-03672 CNVD-2022-10270
* OS Command Injection in Nexus Repository Manager 2.x (CVE-2019-5475) 
* Panabit Application Gateway ajax_top backstage RCE
* Panabit iXCache ajax_cmd backstage RCE
* Panabit Panalog cmdhandle.php backstage RCE
* Panabit Panalog sy_addmount.php RCE
* Panabit Panalog sy_query.php RCE
* Pandora FMS SQL Injection (CVE-2021-32099)
* Payara Micro Community Information Leakage (CVE-2021-41381)
* PbootCMS 3.0.4 RCE (CNVD-2021-32163)
* PbootCMS parserIfLabel RCE
* Pentaho Business Analytics 9.1 Authentication Bypass (CVE-2021-31602)
* Pentaho Business Analytics 9.1 Information leakage (CVE-2021-31601)
* Pentaho Business Analytics 9.1 query sqli (CVE-2021-34684)
* PHP 8.1.0-dev Zerodium Backdoor vulnerabilities
* php8.1backdoor
* PHPStudy Backdoor Remote Code execution
* PHPUnit CVE-2017-9841 Arbitrary Code Execution Vulnerability
* PHP 8.1.0-dev Zerodium Backdoor RCE
* pigcms action_export File Download
* pigcms action_flashUpload File Upload
* POCID5463 ZZcms开源招商网CMS系统最新版8.3版本dl_download页面前台sql注入
* POCID5467 ZZcms开源招商网CMS系统最新版8.3版本前台sql注入
* POCID5885 zzzphp 1.5.9 front Sqli
* POCID5887 zzzphp系统最新版1.5.9版本前台代码执行
* POCID5969 zzzphp系统信息泄露
* POCID5971 zzzphp 1.5.9 front code execution
* POCID6397 zzzphp 1.6.1 Get database information
* Polycom RMX 1000 Default Credentials
* Polycom RSS 2000 Default Credentials
* Polycom RSS 4000 Default Credentials
* Portainer Init Deploy CVE-2018-19367
* PowerCreator CMS Arbitrary File Upload
* Progress Telerik UI for ASP.NET AJAX Deserialization (CVE-2019-18935)
* PublicCMS 202011 Auth SSRF
* Pulse Secure SSL VPN Arbitrary File Read (CVE-2019-11510)
* PySpider Unauthorized Access RCE
* Qi An Xin Wang Sheng VPN file upload
* QiAnXin Tianqing terminal security management system client_upload_file.json getshell
* QiAnXin Tianqing terminal security management system unauthorized access
* Qilai OA CloseMsg.aspx SQL injection
* qilaiOA messageurl.aspx SQLinjection
* qilaiOA treelist.aspx SQLinjection
* QNAP Photo Station APP Local File Read (CVE-2019-7192)
* QuarkMail web2cgi rce
* Rails Asset Pipeline Directory Traversal (CVE-2018-3760)
* RaspAP Operating System Command Injection Vulnerability (CVE-2021-33357)
* Red Hat Jboss Application Server CVE-2017-7504 Remote Code Execution Vulnerability
* Red Hat Jboss Enterprise Application Platform CVE-2017-12149 Remote Code Execution Vulnerability
* Redash 10.0.0 default SECRET_KEY (CVE-2021-41192)
* Red sail-ioffice OA hospital ioFileExport.aspx file read
* Reporter system Http_Host_User.php SQL injection
* RG-UAC
* Riskscanner list SQL injection
* RMI remote deserialize rce vulnerability
* RockMongo default account
* Ruijie EG branch_passw.php rce
* Ruijie EG cli.php rce
* Ruijie EG login.php rce
* Ruijie EG RCE
* Ruijie EG update.php RCE
* Ruijie NBR Router RCE
* Ruijie RG-UAC Information Disclosure CNVD-2021-14536
* Ruijie RG UAC Password leakage
* Ruijie Networks EWEB Network Management System RCE CNVD-2021-09650
* Ruijie RG UAC Password leakage CNVD-2021-14536
* Ruijie Smartweb Default Password CNVD-2020-56167
* Ruijie Smartweb Management System Password Information Disclosure CNVD-2021-17369
* Ruijie smartweb password information disclosure
* Ruijie smartweb weak password
* RuoYi Druid Unauthorized access
* S2 NetBox RCE
* SaltStack pillar_roots.write File Write (CVE-2021-25282)
* SaltStack RCE (CVE-2020-11651)
* SaltStack RCE (CVE-2020-16846)
* Samsung WLAN AP WEA453e RCE
* Samsung WLAN AP WEA453e RCE
* Samsung WLAN AP wea453e router RCE
* SangFor Application Delivery Arbitrary File Download
* SangFor Application Delivery login.php Command Execution
* Sangfor EDR 3.2.21 Arbitrary code execution vulnerability
* Sangfor EDR anyuser login
* Sangfor EDR unauthorized RCE (CNVD-2020-46552)
* Sangfor VDI unauthorized RCE
* 深信服 行为感知系统 c.php 远程命令执行漏洞
* SAP NetWeaver Authentication Bypass (CVE-2020-6287) RECON
* Sapido syscmd.htm RCE (CNVD-2021-32085)
* Scalar i40 Default Credentials
* Scrapyd Unauthorized Access RCE
* SDWAN Smart Gateway Default Password
* SDWAN智能网关应用系统弱口令
* SEACMS sql.class.php GetShell
* Security Devices Hardcoded Password
* SECWORLD Next generation firewall pki_file_download File read
* Seeyon File Read (CNVD-2020-62422)
* Seeyon OA A8 unauth file upload getshell
* Seeyon OA admin cookie leakage
* Seeyon OA administrator cookie leakage file upload
* Seeyon OA Fastjson loginController.do RCE
* Seeyon OA A6 DownExcelBeanServlet User information leakage
* Seeyon OA A6 initDataAssess.jsp User information leakage
* Seeyon OA A6 setextno.jsp SQL injection
* Seeyon OA A6 test.jsp SQL injection
* Seeyon OA A6 createMysql.jsp Disclosure of database sensitive information
* Seeyon OA A8-m Information leakage
* Selea OCR-ANPR get_file.php File read
* Selea OCR-ANPR SeleaCamera File read
* Sentinel Sentinel-dashboard SSRF
* Shenzhen West dieter Technology Co LTD CPE-WiFi tracert RCE
* Shiziyu CMS wxapp.php file upload getshell
* ShiziyuCms ApiController.class.php SQL injection
* ShiziyuCms ApigoodsController.class.php SQL injection
* 狮子鱼CMS ApiController.class.php SQL injection vulnerability
* shiziyuCMS ApigoodController.class.php SQL
* ShopXO download File read (CNVD-2021-15822)
* ShopXO download 任意文件读取漏洞 CNVD-2021-15822
* ShopXO Fileread CNVD-2021-15822
* ShowDoc uploadImg Arbitrary file upload
* showDocGo
* shterm(QiZhi) fortress Arbitrary user login
* shterm fortress machine tui_download.php rce
* shterm fortress machine weak password
* shterm fortress machine worksheet_check.php rce
* shterm(QiZhi) Fortress Arbitrary User Login
* Shterm(QiZhi) Fortress Unauthorized Access CNVD-2019-27717
* Smartbi某接口存在SQL注入，无需身份认证的攻击者可利用该漏洞查看数据库中的敏感信息或删除任意用户
* Smartbi存在任意文件读取漏洞，具有普通用户权限的攻击者利用该漏洞可以读取任意文件
* Smarters WEB TV PLAYER player command execution(CVE-2020-9380)
* Softneta MedDream 6.7.11 Directory Traversal
* Solar-Log incorrect access control infoleak
* SolarWinds Orion Local File Disclosure (CVE-2020-10148)
* SonarQube search_projects information
* SonarQube unauth CVE-2020-27986
* SonarQube unauth CVE-2020-27986
* SonicWall SSL-VPN 远程命令执行漏洞
* SonicWall SSL-VPN 远程命令执行漏洞
* SonicWall SSL-VPN Unauthorized RCE
* Sonicwall SSLVPN ShellShock RCE
* SonicWall SSL-VPN RCE
* SpiderFlow save  remote code
* SPON IP network intercom broadcast system exportrecord.php any file download
* SPON IP network intercom broadcast system getjson.php Arbitrary file read
* SPON IP network intercom broadcast system ping.php any file read
* SPON IP network intercom broadcast system ping.php RCE
* Spring Boot 1.5 SnakeYAML RCE
* Spring Cloud Config Server Directory Traversal (CVE-2019-3799)
* Spring Cloud Config Server Directory Traversal (CVE-2020-5410)
* Spring Cloud Function SPEL Vulnerability
* Spring Core Framework Remote Code Execution Vulnerability(CVE-2022-22965)
* Spring Data Commons RCE (CVE-2018-1273)
* Spring Boot Actuator Logview Path Traversal CVE-2021-21234
* Spring boot actuator unauthorized access
* Spring Cloud Function SpEL RCE CVE-2022-22963
* Spring Cloud Gateway Actuator API SpEL Code Injection CVE-2022-22947
* Struts S2-048 2.3.x saveGangster.action RCE (CVE-2017-9791)
* Struts2 009 Apache Struts 'ParameterInterceptor' Class OGNL (CVE-2011-3923) Security Bypass Vulnerability
* Struts2 032 Apache Struts CVE-2016-3081 Remote Code Execution Vulnerability
* Struts2 S2-016 RCE (CVE-2013-2251) spaw
* Struts2 S2-016 RCE (CVE-2013-2251)
* Struts2 S2-046 Struts2.3.5-2.3.31/Struts2.5-2.5.10 Content-Disposition RCE (CVE-2017-5638) spaw
* Struts2 S2-046 Struts2.3.5-2.3.31/Struts2.5-2.5.10 Content-Disposition RCE (CVE-2017-5638)
* Struts2 S2-057 RCE (CVE-2018-11776)
* Struts2 S2-061 RCE (CVE-2020-17530)
* Struts2 Log4Shell CVE-2021-44228 (1)
* Struts2 Log4Shell CVE-2021-44228 (2)
* Struts2 Log4Shell CVE-2021-44228 (3)
* Struts2 Log4Shell CVE-2021-44228 (1)
* Struts2 Log4Shell CVE-2021-44228 (2)
* Struts2 Log4Shell CVE-2021-44228 (3)
* SugarCRM REST Unserialize PHP Code Execution
* Supervisor XML-RPC Authenticated Remote Code Execution
* SuperWebmailer RCE (CVE-2020-11546)
* SVN repository found
* Symantec Advanced Threat Protection log4j2 Remote command execution vulnerability (CVE-2021-44228)
* Symfony framework debug Local File Inclusion
* TamronOS IPTV ping RCE
* TamronOS IPTV系统后台任意文件下载
* TamronOS IPTV系统存在前台命令执行漏洞
* TamronOS IPTV system Filedownload CNVD-2021-45711
* TamronOS IPTV system RCE
* Tenda AC15 1900 telnet 后门
* Terramaster F4-210 Arbitrary File Read
* Terramaster F4-210 Arbitrary User Add
* Terramaster F4-210 name RCE
* TerraMaster TOS Information Disclosure (CVE-2020-28185)
* TerraMaster TOS RCE (CVE-2020-15568)
* TerraMaster TOS RCE (CVE-2020-28188)
* Terramaster TOS VPN RCE
* Tianwen ERP system FileUpload CNVD-2020-28119
* Tianwen ERP system  uploadfile.aspx Arbitraryvfilevupload
* Tiki Wiki CMS RCE (CVE-2020-15906 CVE-2021-26119)
* tomcat lfi (CVE-2020-1938)
* tongda OA action_upload.php file upload getshell
* tongda OA any file delete getshell
* Tongda OA api.ali.php RCE
* Tongda OA Arbitrary User Login Vulnerability
* tongda OA file include getshell
* tongda OA front end sqli
* TongDa OA report_bi.func.php SQLI
* tongda OA user session leakage
* 通达oa未授权访问
* Topsec DLP unauthorized password change
* Topsec Firewall default account
* TOPSEC Firewall maincgi cgi RCE
* Topsec Firewall telnet default account
* TopSec Reporter Arbitrary file download CNVD-2021-41972
* Topsec TopAppLB Any account Login
* Topsec TopAppLB enable tool debug.php RCE
* TotoLink FileName RCE(CVE-2022-26210)
* TOTOLINK routers remote command injection vulnerabilities (CVE-2020-25499)
* TP-Link NCxxx Command Injection CVE-2020-12109
* TP-LINK TL-ER8820T Default password
* TPShop 3.x SQL Injection
* Traccar Default password
* TRS-MAS testCommandExecutor.jsp Remote Command Execution
* Tuchuang Library System Arbitrary Reading File (CNVD-2021-34454)
* U8-OA
* ultrapower cmdserver cloud management platform remote command execution
* Unauthenticated Multiple D-Link Routers RCE CVE-2019-16920
* Undocumented user account in Zyxel products
* UniFi Network Log4shell CVE-2021-44228
* UniFi Network Log4shell CVE-2021-44228
* Uniview Cameras main cgi RCE
* unraid 6.8.0 authenticate bypass remote code execution(CVE-2020-5847)
* UNV ip camera RCE (CNVD-2020-31565)
* UTT Net Management System default password CNVD-2021-23505
* vBulletin 5.x RCE (CVE-2019-16759)
* vBulletin Pre-Auth RCE Vulnerability CVE-2020-17496
* vBulletin SQLi (CVE-2020-12720)
* VENGD upload-file Arbitrary file upload
* VENGD Arbitrary File Upload
* Venustech TianYue default account
* VICIdial Information leakage (CVE-2021-28854)
* VMware vCenter Arbitrary File Read
* VMware vCenter file upload (CVE-2021-22005)
* VMware vCenter provider-logo Arbitrary File Read
* VMware vCenter rce (CVE-2021-22017)
* VMware vCenter Server RCE (CVE-2021-21972)
* VMware View Planner RCE (CVE-2021-21978)
* VMware vSphere Client (HTML5) RCE (CVE-2021-21985)
* VMware Workspace ONE Access & Identity Manager Remote Code Execution (CVE-2022-22954)
* VMWare Horizon Log4shell CVE-2021-44228
* VMWare Horizon Log4shell CVE-2021-44228
* VMware NSX Log4shell CVE-2021-44228
* VMware NSX Log4shell CVE-2021-44228
* VMWare Operations vRealize Operations Manager API SSRF CVE-2021-21975
* VMware vCenter Log4shell CVE-2021-44228 (1)
* VMware vCenter Log4shell CVE-2021-44228 (1)
* VMware vCenter v7.0.2 Arbitrary File Read
* VMware Workspace ONE Access and Identity Manager Server-Side Template Injection CVE-2022-22954
* VMware Workspace ONE Access RCE CVE-2022-22954
* VoipMonitor utilities.php SQL Injection (CVE-2022-24260)
* WangKang Next generation firewall router RCE
* WangKang NS-ASG cert_download.php File read
* wangyixingyun waf Information leakage
* Wanhu ezOFFICE configuration file download vulnerability
* WAVLINK WN535G3 POST XSS CVE-2022-30489
* Wayos AC集中管理系统默认弱口令  CNVD-2021-00876
* Wayos AC Centralized management system Default Password CNVD-2021-00876
* Wayos AC Centralized management system Default weak password (CNVD-2021-00876)
* Weaver e-Bridge Arbitrary File Download
* Weaver e-cology OA Action.jsp MobileAppUploadAction file upload
* Weaver e-cology OA apps.ktree.servlet.KtreeUploadAction file upload
* Weaver e-cology OA check API file upload getshell
* Weaver e-cology OA Database config leakage
* Weaver e-cology OA file download (CNVD-2019-29900)
* Weaver e-cology OA file read (CNVD-2019-29902)
* Weaver e-cology OA getdata.jsp sqli
* Weaver e-cology OA RCE (CNVD-2019-32204)
* Weaver e-cology OA SQLi (CNVD-2019-34241)
* Weaver e-cology OA SQLi
* weaver e-cology oa system front page sql injection
* Weaver e-cology OA uploadOperation.jsp file upload
* Weaver e-cology OA XXE
* Weaver E-Office SQL Injection Vulnerability (CNVD-2022-43246)
* Weaver-EMobile login.do Struts2 RCE
* Weaver EOffice UploadFile.php File Upload (CNVD-2021-49104)
* Weaver e_cology OA XStream Remote Code Execution
* Weaver-OA E-Cology WorkflowServiceXml RCE
* Weaver OA e-office upload file upload
* Weaver OA weaver.common.Ctrl
* Weaver EOffice Arbitrary File Upload CNVD-2021-49104
* 泛微 EOffice Arbitrary File Upload CNVD-2021-49104
* Weaver e office UploadFile.php file upload CNVD-2021-49104
* Weaver OA 8 SQL injection
* weaver OA E-Cology getSqlData SQL injection vulnerability
* Webgrind_File_read_cve-2018-12909
* Weblogic LDAP RCE CVE-2021-2109
* Weblogic LDAP 远程代码执行漏洞 CVE-2021-2109
* Weblogic LDAP 远程代码执行漏洞 CVE-2021-2109
* Weblogic SSRF漏洞 CVE-2014-4210
* Weblogic SSRF漏洞 CVE-2014-4210
* WebLogic deserialize asyncresponseservice(CVE-2019-2725)
* Weblogic IIOP RCE (CVE-2020-2551)
* Weblogic ReflectionExtractor RCE (CVE-2020-2555)
* WebLogic SearchPublicRegistries SSRF(CVE-2014-4210)
* Weblogic Secondary Deserialization RCE (CVE-2021-2135)
* Weblogic Server RCE (CVE-2021-2109)
* WebLogic XML External Entity (XXE) Injection (CVE-2019-2647)
* Weblogic_LDAP RCE_CVE-2021-2109
* WebLogic SearchPublicRegistries SSRF(CVE-2014-4210)
* Webmin RCE (CVE-2019-15107)
* Websphere Portal SSRF
* Websvn 2.6.0 RCE (CVE-2021-32305)
* WebSVN before 2.6.1 Injection RCE CVE-2021-32305
* WeiPHP 3.0 session_id File Upload Getshell
* WeiPHP Arbitrary File Read (CNVD-2020-68596)
* Western Digital My Cloud's snmp_mgr.cgi file multiple parameter command execution
* Wheelon-e Ditong VPN infoformation leakage
* Wordpress Duplicator 1.3.26 Arbitrary File Read (CVE-2020-11738)
* WordPress Email Subscribers和Newsletters插件4.2.3版本未认证文件下载漏洞
* WordPress PageViewsCount Plugin SQL Injection
* WordPress Plugin Mailpress 4.5.2 RCE
* WordPress Plugin SecureCopyContentProtection SQLi CVE-2021-24931
* WordPress redux-framework Information Disclosure (CVE-2021-38314)
* WordPress WP Live Chat Support Pro Plugin < 8.0.26 Arbitrary File Upload Vulnerability
* Wordpress Zoomsounds Arbitrary File Read (CVE-2021-39316)
* WordPress Simple Ajax Chat plugin InfoLeak CVE-2022-27849
* WordPress WPQA plugin Unauthenticated Private Message Disclosure CVE-2022-1598
* WSO2 fileupload 任意文件上传漏洞 CVE-2022-29464
* WSO2 Management Console Reflected XSS CVE-2022-29548
* WSO2 Management Console Unrestricted Arbitrary File Upload RCE CVE-2022-29464
* xiaomi Mi wiFi From File Read To Login (CVE-2019-18370)
* Xieda OA system bypasses login authentication
* Xieda-oa
* Xieda OA Filedownload CNVD-2021-29066
* XMDNS command execution
* Xunyou CMS Local File read (CNVD-2020-23735)
* XWork 'ParameterInterceptor' Class OGNL (CVE-2010-1870) Security Bypass Vulnerability
* XXL-JOB 任务调度中心 后台默认弱口令
* XXL-JOB 任务调度中心 后台默认弱口令
* XXL-JOB API Unauthenticated RCE
* XXL-JOB Default Login
* XXL-JOB Default password
* YApi Unauthorized Creation User And Mock RCE
* YAPI RCE
* YCCMS XSS
* Yinpeng Hanming Video Conferencing Arbitrary file read (CNVD-2020-62437)
* Yinpeng Hanming Video Conferencing Filedownload CNVD-2020-62437
* Yinpeng Hanming Video Conferencing  Arbitrary file read (CNVD-2020-62437)
* YiShaAdmin 3.1 Arbitrary File Read
* yiyou  moni_detail.do Remote command execution
* Yongyou NC bsh.servlet.BshServlet RCE
* 用友 NC bsh.servlet.BshServlet 远程命令执行漏洞
* Yonyou GRP-U8 RCE with SQLi
* Yonyou NC Arbitrary File Include
* Yonyou NC BaseApp UploadServlet Deserialization RCE
* Yonyou NC dcupdateService Deserialization RCE
* Yonyou NC MonitorServlet Deserialization RCE
* Yonyou TurboCRM strresview sqli
* Yonyou U8-OA test.jsp RCE with SQLi
* Yonyou-UFIDA-NC-bsh.servlet.BshServlet-rce
* yuanchuangxianfeng unauthorized access vulnerability
* yunshidai ERP SQL injection
* YUNUCMS API link interface SQLi
* YUNUCMS API list interface SQLi
* yycms-XSS
* Zabbix CVE-2016-10134 SQL Injection Vulnerability
* Zabbix default account
* zabbix-saml-cve-2022-23131身份认证绕过
* Zeroshell RCE (CVE-2019-12725)
* Zhejiang Dahua DSS System Filedownload CNVD-2020-61986
* 智慧综合管理平台 FileDownLoad.aspx 任意文件读取漏洞
* ZhongkeWangwei Next generation firewall File read
* ZhongQing naibo Education Cloud Platform Information leakage
* ZhongQing naibo Education Cloud platform reset password
* Zhongxing F460 web_shell_cmd.gch RCE
* ZhongXinJingDun  Information security management system  Default administrator password
* ZhongXinJingDun Information Security Management System Default Login
* ZhongYuan iAudit get_luser_by_sshport.php RCE
* ziguang editPass.html SQL injection CNVD-2021-41638
* Zimbra Collaboration Suite sfdc_preauth.jsp SSRF
* Zimbra XXE (CVE-2019-9670)
* Zoho ManageEngine ADSelfService Plus Username Enumeration
* Zoho ManageEngine Desktop Central 10 getChartImage rce (CVE-2020-10189)
* Zoho ManageEngine ServiceDesk Plus RCE (CVE-2021-44077)
* ZTE WLAN Controller SQLi to get admin password
* ZTE ZSR router system default password
* ZyXEL NAS RCE (CVE-2020-9054)
* Zyxel ZTP RCE (CVE-2022-30525)
* ZZZCMS parserSearch RCE
* zzzcms zzzphp parserIfLabel Template Injection Remote Code Execution (CVE-2021-32605)
* ZZZCMS parserSearch rce
* zzzphp建站系统最新版1.6.1版本sql注入
* 宝塔面板数据库未授权访问
* 帆软报表 v8.0 任意文件读取漏洞 CNVD-2018-04757
* laifuyun_sqli
* 腾达路由器 setusbunload 命令执行漏洞 （CVE-2020-10987）
* 致远OA A6 数据库敏感信息泄露
* 致远OA A6 用户敏感信息泄露
* 致远OA htmlofficeservlet文件上传getshell
* 致远OA webmail.do任意文件下载 CNVD-2020-62422
* 蜂网互联 企业级路由器v4.31 密码泄露漏洞 CVE-2019-16313
* 通达OA 11.5版本存在swfupload_new文件SQL注入
* 锐捷NBR路由器 EWEB网管系统 远程命令执行漏洞




