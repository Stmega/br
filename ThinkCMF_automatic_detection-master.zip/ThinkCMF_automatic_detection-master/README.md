
# ThinkCMF框架任意内容包含漏洞批量检测getshell

## 影响版本:

- ThinkCMF X1.6.0
- ThinkCMF X2.1.0
- ThinkCMF X2.2.0
- ThinkCMF X2.2.1
- ThinkCMF X2.2.2
- ThinkCMF X2.2.3

 usage: python thinkcmf.py 

	输入IP：10.10.1.1/24
		   10.10.12.212/16
			
 