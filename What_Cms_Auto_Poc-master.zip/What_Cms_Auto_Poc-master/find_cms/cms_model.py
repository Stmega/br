# -*- coding: utf-8 -*-

class Cms_Model:
    def __init__(self):
        '''cms模型，记录各种参数'''
        self.name = ""
        self.url = ""
        self.type=None
        #self.flag
