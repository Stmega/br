# What_Cms_Auto_Poc
What_Cms_Auto_Poc是由本人开发，根据CMS指纹库自动识别CMS，进而加载相关的POC验证漏洞.




# 使用用法
    help              帮助
    show              显示参数设置
    set url           目标url                set url http://example.com/
    set type          设置CMS类型，设置后可
                      跳过CMS识别            set type example
    list              显示支持的CMS
    search            搜索POC                search example
    run               执行
    exit              退出



# 平台
 python3




# 说明
1.部分代码参考网上公开的脚本。

2.本工具仅限于进行漏洞验证，如若因此引起相关法律问题，概不负责。

3.所有POC均为开源，以后也一直如此，供大家参考和学习。





